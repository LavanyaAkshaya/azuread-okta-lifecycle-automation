# AzureAD-Okta Lifecycle Automation

## 📘 Overview
This repository demonstrates a sample **IAM automation workflow** that synchronizes user lifecycle events (Joiner, Mover, Leaver) between **Azure Active Directory (Entra ID)** and **Okta** using PowerShell scripts.

All examples use mock data — **no real credentials or API calls** — making it safe for educational or interview demonstrations.

---

## ⚙️ Features
✅ Automates onboarding of Active users  
✅ Synchronizes role updates between Azure AD and Okta  
✅ Deactivates Inactive users automatically  
✅ Uses PowerShell scripting for simulation  
✅ Mock data-driven (safe for GitHub)  

---

## 📁 Repository Structure
| Folder | Description |
|---------|-------------|
| `scripts/` | Contains PowerShell automation scripts |
| `data/` | Includes mock user data (CSV file) |
| `README.md` | Documentation for the project |

---

## 🚀 How to Run
1. Clone this repository:
   ```bash
   git clone https://github.com/<your-username>/azuread-okta-lifecycle-automation.git
   ```

2. Open PowerShell and navigate to the `scripts` directory:
   ```powershell
   cd azuread-okta-lifecycle-automation/scripts
   ```

3. Run the scripts in order:
   ```powershell
   ./01_onboard_user.ps1
   ./02_update_user_role.ps1
   ./03_offboard_user.ps1
   ```

You’ll see simulated onboarding, updates, and deactivation logs in the console.

---

## 🧠 Skills Demonstrated
- Azure AD (Entra ID) lifecycle management  
- Okta user provisioning and deprovisioning concepts  
- PowerShell scripting and automation  
- Identity Governance and Zero Trust awareness  
- Mock API logic for integration workflow  

---

## ✨ Author
**Chinta Lavanya Akshaya**  
Sr. IAM Engineer | Identity Governance | Zero Trust  
📧 lavanya1chinta@gmail.com
