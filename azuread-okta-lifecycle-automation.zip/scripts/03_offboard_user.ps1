# =====================================================
# Script: 03_offboard_user.ps1
# Author: Chinta Lavanya Akshaya
# Description: Simulates user deactivation in Azure AD and Okta
# =====================================================

Import-Csv "../data/sample_users.csv" | ForEach-Object {
    if ($_.Status -eq "Inactive") {
        Write-Host "----------------------------------------"
        Write-Host "🔻 Initiating offboarding for user: $($_.DisplayName)"
        
        # Simulated Azure AD account disable
        Start-Sleep -Seconds 1
        Write-Host "🔹 Azure AD: Account disabled successfully."
        
        # Simulated Okta account deactivation
        Start-Sleep -Seconds 1
        Write-Host "🔹 Okta: Account deactivated successfully."
        
        Write-Host "✅ Offboarding completed for $($_.DisplayName)."
        Write-Host "----------------------------------------`n"
    }
}
Write-Host "🎯 Offboarding process completed for all Inactive users."
