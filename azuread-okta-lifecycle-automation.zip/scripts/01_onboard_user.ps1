# =====================================================
# Script: 01_onboard_user.ps1
# Author: Chinta Lavanya Akshaya
# Description: Simulates user onboarding into Azure AD and Okta
# =====================================================

Import-Csv "../data/sample_users.csv" | ForEach-Object {
    if ($_.Status -eq "Active") {
        Write-Host "----------------------------------------"
        Write-Host "🔹 Starting onboarding for user: $($_.DisplayName)"
        
        # Simulated Azure AD API call
        Start-Sleep -Seconds 1
        Write-Host "✅ User $($_.DisplayName) created in Azure AD (Entra ID)."
        
        # Simulated Okta API call
        Start-Sleep -Seconds 1
        Write-Host "✅ User $($_.DisplayName) provisioned successfully in Okta."
        
        Write-Host "----------------------------------------`n"
    }
}
Write-Host "🎯 Onboarding process completed for all Active users."
