# =====================================================
# Script: 02_update_user_role.ps1
# Author: Chinta Lavanya Akshaya
# Description: Simulates updating user roles in Azure AD and Okta
# =====================================================

Import-Csv "../data/sample_users.csv" | ForEach-Object {
    Write-Host "----------------------------------------"
    Write-Host "🔸 Updating role for user: $($_.DisplayName)"
    
    # Simulated Azure AD role update
    Start-Sleep -Seconds 1
    Write-Host "🔹 Azure AD: Updated role to '$($_.Role)'."
    
    # Simulated Okta role update
    Start-Sleep -Seconds 1
    Write-Host "🔹 Okta: Role synchronized to '$($_.Role)'."
    
    Write-Host "✅ Role updates completed for $($_.DisplayName)."
    Write-Host "----------------------------------------`n"
}
Write-Host "🎯 Role update synchronization complete for all users."
